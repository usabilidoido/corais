
class AbiConverterError(Exception):
    pass

class AbiCommandError(Exception):
    pass

class ToolsConverterError(Exception):
    pass
